package com.example.veronikahelloapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// This class manages the SQLite database for users and events.
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and version.
    private static final String DATABASE_NAME = "VeronikaApp.db";
    private static final int DATABASE_VERSION = 1;

    // Table names.
    private static final String TABLE_USERS = "users";
    private static final String TABLE_EVENTS = "events";

    // Constructor.
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // This method runs when the database is created for the first time.
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create the users table.
        db.execSQL(
                "CREATE TABLE " + TABLE_USERS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT UNIQUE, " +
                        "password TEXT)"
        );

        // Create the events table.
        db.execSQL(
                "CREATE TABLE " + TABLE_EVENTS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL, " +
                        "date TEXT NOT NULL)"
        );
    }

    // This method runs if the database version changes.
    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion
    ) {

        // Remove old tables.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);

        // Recreate the database.
        onCreate(db);
    }

    // CREATE USER:
    // Saves a new username and password in the database.
    public boolean createUser(
            String username,
            String password
    ) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert(
                TABLE_USERS,
                null,
                values
        );

        return result != -1;
    }

    // READ USER:
    // Checks whether the entered username and password exist.
    public boolean checkUser(
            String username,
            String password
    ) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT id FROM " + TABLE_USERS +
                        " WHERE username=? AND password=?",
                new String[]{username, password}
        );

        boolean userExists = cursor.moveToFirst();

        cursor.close();

        return userExists;
    }

    // CREATE EVENT:
    // Adds a new event to the database.
    public long addEvent(
            String name,
            String date
    ) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("date", date);

        return db.insert(
                TABLE_EVENTS,
                null,
                values
        );
    }

    // READ EVENTS:
    // Returns all events stored in the database.
    public Cursor getEvents() {

        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery(
                "SELECT id, name, date FROM " +
                        TABLE_EVENTS +
                        " ORDER BY id ASC",
                null
        );
    }

    // UPDATE EVENT:
    // Changes the name and date of an existing event.
    public boolean updateEvent(
            int id,
            String name,
            String date
    ) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("date", date);

        int rowsUpdated = db.update(
                TABLE_EVENTS,
                values,
                "id=?",
                new String[]{String.valueOf(id)}
        );

        return rowsUpdated > 0;
    }

    // DELETE EVENT:
    // Removes an event from the database.
    public boolean deleteEvent(int id) {

        SQLiteDatabase db = getWritableDatabase();

        int rowsDeleted = db.delete(
                TABLE_EVENTS,
                "id=?",
                new String[]{String.valueOf(id)}
        );

        return rowsDeleted > 0;
    }
}