package com.example.veronikahelloapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// Adapter used to display events inside RecyclerView.
public class EventAdapter
        extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    public interface OnEventActionListener {
        void onEventSelected(Event event);
        void onEventDelete(Event event);
    }

    private final List<Event> eventList;
    private final OnEventActionListener listener;

    public EventAdapter(
            List<Event> eventList,
            OnEventActionListener listener
    ) {
        this.eventList = eventList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {

        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.item_event, parent, false);

        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull EventViewHolder holder,
            int position
    ) {

        Event event = eventList.get(position);

        holder.eventName.setText(event.getName());
        holder.eventDate.setText(event.getDate());

        // Select event for editing.
        holder.itemView.setOnClickListener(
                v -> listener.onEventSelected(event)
        );

        // Delete the selected event.
        holder.deleteButton.setOnClickListener(
                v -> listener.onEventDelete(event)
        );
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    static class EventViewHolder extends RecyclerView.ViewHolder {

        TextView eventName;
        TextView eventDate;
        Button deleteButton;

        EventViewHolder(@NonNull View itemView) {
            super(itemView);

            eventName =
                    itemView.findViewById(R.id.itemEventName);

            eventDate =
                    itemView.findViewById(R.id.itemEventDate);

            deleteButton =
                    itemView.findViewById(R.id.itemDeleteButton);
        }
    }
}