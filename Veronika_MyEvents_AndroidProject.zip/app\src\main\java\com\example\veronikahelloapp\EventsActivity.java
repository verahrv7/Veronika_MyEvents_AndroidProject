package com.example.veronikahelloapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

// This activity displays all events from the SQLite database
// and allows the user to create, read, update, and delete events.
public class EventsActivity extends AppCompatActivity {

    // Input fields used to create or update an event.
    private EditText eventNameInput;
    private EditText eventDateInput;

    // Buttons for CRUD actions and SMS settings.
    private Button saveEventButton;
    private Button updateEventButton;
    private Button smsButton;

    // RecyclerView displays all database events.
    private RecyclerView eventsRecyclerView;

    // Database helper used to access SQLite.
    private DatabaseHelper databaseHelper;

    // List used by RecyclerView.
    private final List<Event> eventList = new ArrayList<>();

    // Adapter used to connect event data to RecyclerView.
    private EventAdapter eventAdapter;

    // Stores the event currently selected for updating.
    private int selectedEventId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Connect this Java class to activity_events.xml.
        setContentView(R.layout.activity_events);

        // Create the SQLite database helper.
        databaseHelper = new DatabaseHelper(this);

        // Connect Java variables to XML views.
        eventNameInput = findViewById(R.id.eventNameInput);
        eventDateInput = findViewById(R.id.eventDateInput);

        saveEventButton = findViewById(R.id.saveEventButton);
        updateEventButton = findViewById(R.id.updateEventButton);
        smsButton = findViewById(R.id.smsButton);

        eventsRecyclerView = findViewById(R.id.eventsRecyclerView);

        // RecyclerView displays the events vertically.
        eventsRecyclerView.setLayoutManager(
                new LinearLayoutManager(this)
        );

        // Create the adapter and define what happens
        // when an event is selected or deleted.
        eventAdapter = new EventAdapter(
                eventList,
                new EventAdapter.OnEventActionListener() {

                    @Override
                    public void onEventSelected(Event event) {
                        selectEvent(event);
                    }

                    @Override
                    public void onEventDelete(Event event) {
                        deleteEvent(event);
                    }
                }
        );

        eventsRecyclerView.setAdapter(eventAdapter);

        // Save a new event.
        saveEventButton.setOnClickListener(v -> saveEvent());

        // Update the currently selected event.
        updateEventButton.setOnClickListener(v -> updateEvent());

        // Open the SMS reminder permission screen.
        smsButton.setOnClickListener(v -> {

            Intent intent = new Intent(
                    EventsActivity.this,
                    SmsActivity.class
            );

            startActivity(intent);
        });

        // Load all events from SQLite.
        loadEvents();
    }

    // CREATE:
    // Adds a new event to the database.
    private void saveEvent() {

        String name = eventNameInput
                .getText()
                .toString()
                .trim();

        String date = eventDateInput
                .getText()
                .toString()
                .trim();

        // Prevent empty event records.
        if (name.isEmpty() || date.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter event name and date",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Insert the event into SQLite.
        long result = databaseHelper.addEvent(name, date);

        if (result != -1) {

            Toast.makeText(
                    this,
                    "Event saved",
                    Toast.LENGTH_SHORT
            ).show();

            clearInputs();

            // Refresh RecyclerView.
            loadEvents();

        } else {

            Toast.makeText(
                    this,
                    "Could not save event",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // READ / SELECT:
    // Loads a selected event into the form so it can be updated.
    private void selectEvent(Event event) {

        selectedEventId = event.getId();

        eventNameInput.setText(event.getName());
        eventDateInput.setText(event.getDate());

        // Enable Update after an event has been selected.
        updateEventButton.setEnabled(true);

        Toast.makeText(
                this,
                "Event selected",
                Toast.LENGTH_SHORT
        ).show();
    }

    // UPDATE:
    // Changes the selected database record.
    private void updateEvent() {

        if (selectedEventId == -1) {

            Toast.makeText(
                    this,
                    "Select an event first",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String name = eventNameInput
                .getText()
                .toString()
                .trim();

        String date = eventDateInput
                .getText()
                .toString()
                .trim();

        if (name.isEmpty() || date.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter event name and date",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        boolean success = databaseHelper.updateEvent(
                selectedEventId,
                name,
                date
        );

        if (success) {

            Toast.makeText(
                    this,
                    "Event updated",
                    Toast.LENGTH_SHORT
            ).show();

            selectedEventId = -1;

            updateEventButton.setEnabled(false);

            clearInputs();
            loadEvents();

        } else {

            Toast.makeText(
                    this,
                    "Could not update event",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // DELETE:
    // Removes an event from SQLite.
    private void deleteEvent(Event event) {

        boolean success = databaseHelper.deleteEvent(
                event.getId()
        );

        if (success) {

            Toast.makeText(
                    this,
                    "Event deleted",
                    Toast.LENGTH_SHORT
            ).show();

            // If the selected event was deleted,
            // clear the editing state.
            if (selectedEventId == event.getId()) {

                selectedEventId = -1;

                updateEventButton.setEnabled(false);

                clearInputs();
            }

            loadEvents();

        } else {

            Toast.makeText(
                    this,
                    "Could not delete event",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // READ:
    // Retrieves every event from SQLite and displays all of them.
    private void loadEvents() {

        // Clear old RecyclerView data.
        eventList.clear();

        Cursor cursor = databaseHelper.getEvents();

        while (cursor.moveToNext()) {

            int id = cursor.getInt(
                    cursor.getColumnIndexOrThrow("id")
            );

            String name = cursor.getString(
                    cursor.getColumnIndexOrThrow("name")
            );

            String date = cursor.getString(
                    cursor.getColumnIndexOrThrow("date")
            );

            // Add each database row to the RecyclerView list.
            eventList.add(
                    new Event(id, name, date)
            );
        }

        cursor.close();

        // Tell RecyclerView that the list changed.
        eventAdapter.notifyDataSetChanged();
    }

    // Clears the event form.
    private void clearInputs() {

        eventNameInput.setText("");
        eventDateInput.setText("");
    }
}

