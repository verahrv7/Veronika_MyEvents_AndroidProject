package com.example.veronikahelloapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// This activity allows the user to create an account and log in.
public class LoginActivity extends AppCompatActivity {

    // Input fields.
    private EditText usernameText;
    private EditText passwordText;

    // Buttons.
    private Button loginButton;
    private Button createAccountButton;

    // Database helper.
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Connect this Java file to activity_login.xml.
        setContentView(R.layout.activity_login);

        // Create database helper.
        databaseHelper = new DatabaseHelper(this);

        // Connect Java variables to XML views.
        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);

        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Login button.
        loginButton.setOnClickListener(v -> loginUser());

        // Create Account button.
        createAccountButton.setOnClickListener(v -> createAccount());
    }

    // Create a new user account.
    private void createAccount() {

        // Read the text entered by the user.
        String username =
                usernameText.getText().toString().trim();

        String password =
                passwordText.getText().toString().trim();

        // Make sure both fields contain text.
        if (username.isEmpty() || password.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter username and password",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Try to save the new account in SQLite.
        boolean success =
                databaseHelper.createUser(
                        username,
                        password
                );

        if (success) {

            Toast.makeText(
                    this,
                    "Account created successfully",
                    Toast.LENGTH_SHORT
            ).show();

        } else {

            Toast.makeText(
                    this,
                    "Account already exists",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Check login information.
    private void loginUser() {

        // Read username and password.
        String username =
                usernameText.getText().toString().trim();

        String password =
                passwordText.getText().toString().trim();

        // Do not allow empty fields.
        if (username.isEmpty() || password.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter username and password",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Check the database for this user.
        boolean success =
                databaseHelper.checkUser(
                        username,
                        password
                );

        if (success) {

            Toast.makeText(
                    this,
                    "Login successful",
                    Toast.LENGTH_SHORT
            ).show();

            // Open the Events screen.
            Intent intent =
                    new Intent(
                            LoginActivity.this,
                            EventsActivity.class
                    );

            startActivity(intent);

        } else {

            Toast.makeText(
                    this,
                    "Invalid username or password",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}