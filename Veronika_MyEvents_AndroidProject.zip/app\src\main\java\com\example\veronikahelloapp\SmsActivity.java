package com.example.veronikahelloapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// This activity handles SMS permission and sends event reminder messages.
public class SmsActivity extends AppCompatActivity {

    // Request code used for the SEND_SMS runtime permission.
    private static final int SMS_PERMISSION_CODE = 100;

    private Button allowSmsButton;
    private Button sendReminderButton;
    private Button notNowButton;

    private EditText phoneNumberInput;
    private TextView statusText;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Connect this Java class to activity_sms.xml.
        setContentView(R.layout.activity_sms);

        databaseHelper = new DatabaseHelper(this);

        // Connect Java variables to XML views.
        allowSmsButton = findViewById(R.id.allowSmsButton);
        sendReminderButton = findViewById(R.id.sendReminderButton);
        notNowButton = findViewById(R.id.notNowButton);

        phoneNumberInput = findViewById(R.id.phoneNumberInput);
        statusText = findViewById(R.id.statusText);

        // Show the current SMS permission state.
        updatePermissionStatus();

        // Ask Android for permission to send SMS messages.
        allowSmsButton.setOnClickListener(v ->
                requestSmsPermission()
        );

        // Send a reminder for an event stored in SQLite.
        sendReminderButton.setOnClickListener(v ->
                sendEventReminder()
        );

        // The application remains usable if SMS permission is declined.
        notNowButton.setOnClickListener(v -> {

            Toast.makeText(
                    SmsActivity.this,
                    "SMS reminders are optional",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
        });
    }

    // Requests SEND_SMS permission if it has not already been granted.
    private void requestSmsPermission() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            updatePermissionStatus();

            Toast.makeText(
                    this,
                    "SMS permission is already enabled",
                    Toast.LENGTH_SHORT
            ).show();

        } else {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    // Called after the user accepts or denies the permission request.
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0
                    && grantResults[0]
                    == PackageManager.PERMISSION_GRANTED) {

                statusText.setText(
                        "Notification status: Enabled"
                );

                sendReminderButton.setEnabled(true);

                Toast.makeText(
                        this,
                        "SMS notifications enabled",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                statusText.setText(
                        "Notification status: Not enabled"
                );

                sendReminderButton.setEnabled(false);

                Toast.makeText(
                        this,
                        "SMS permission denied. The rest of the app will still work.",
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    // Sends an SMS reminder for the first event stored in the database.
    private void sendEventReminder() {

        String phoneNumber = phoneNumberInput
                .getText()
                .toString()
                .trim();

        if (phoneNumber.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter a phone number",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Verify permission before attempting to send SMS.
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    this,
                    "SMS permission is required",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        Cursor cursor = databaseHelper.getEvents();

        // The reminder uses an event that the user created in SQLite.
        if (!cursor.moveToFirst()) {

            cursor.close();

            Toast.makeText(
                    this,
                    "Add an event before sending a reminder",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String eventName = cursor.getString(
                cursor.getColumnIndexOrThrow("name")
        );

        String eventDate = cursor.getString(
                cursor.getColumnIndexOrThrow("date")
        );

        cursor.close();

        String message =
                "My Events reminder: "
                        + eventName
                        + " is scheduled for "
                        + eventDate
                        + ".";

        try {

            // SmsManager sends the SMS message.
            SmsManager smsManager = SmsManager.getDefault();

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Event reminder sent",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "SMS could not be sent",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // Updates the screen based on the user's current permission choice.
    private void updatePermissionStatus() {

        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                )
                        == PackageManager.PERMISSION_GRANTED;

        if (permissionGranted) {

            statusText.setText(
                    "Notification status: Enabled"
            );

            sendReminderButton.setEnabled(true);

        } else {

            statusText.setText(
                    "Notification status: Not enabled"
            );

            sendReminderButton.setEnabled(false);
        }
    }
}